
# Exam AI System

## Run Backend
npm install
node backend/server.js

## Features
- Login API
- Upload API
- Results API
- AI module placeholder
