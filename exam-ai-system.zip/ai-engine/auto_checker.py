
def check(marks):
    if marks > 75:
        return "A"
    elif marks > 60:
        return "B"
    else:
        return "C"
