
const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");

const auth = require("./routes/auth");
const upload = require("./routes/upload");
const results = require("./routes/results");

const app = express();

app.use(cors());
app.use(bodyParser.json());

app.use("/auth", auth);
app.use("/upload", upload);
app.use("/results", results);

app.listen(5000, ()=>{
  console.log("Server running on http://localhost:5000");
});
