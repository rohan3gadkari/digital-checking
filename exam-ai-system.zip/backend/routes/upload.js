
const express = require("express");
const multer = require("multer");
const router = express.Router();

const storage = multer.diskStorage({
  destination:"backend/uploads",
  filename:(req,file,cb)=>{
    cb(null,Date.now()+"_"+file.originalname);
  }
});

const upload = multer({storage});

router.post("/", upload.single("file"), (req,res)=>{
  res.json({
    message:"File uploaded",
    file:req.file.filename
  });
});

module.exports = router;
