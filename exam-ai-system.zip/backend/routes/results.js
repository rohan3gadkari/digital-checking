
const express = require("express");
const router = express.Router();

router.get("/",(req,res)=>{
  res.json([
    {name:"Student A",marks:85},
    {name:"Student B",marks:72}
  ]);
});

module.exports = router;
