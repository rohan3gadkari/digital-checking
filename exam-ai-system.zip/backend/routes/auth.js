
const express = require("express");
const router = express.Router();

router.post("/login",(req,res)=>{
  const {username,password} = req.body;

  if(username==="admin" && password==="1234"){
    res.json({message:"Login success",role:"admin"});
  } else {
    res.json({message:"Login failed"});
  }
});

module.exports = router;
